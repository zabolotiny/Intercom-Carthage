//
//  ICMSafeNetworkModel.h
//  Pods
//
//  Created by James Treanor on 23/02/2015.
//
//

#import <Foundation/Foundation.h>

@interface ICMSafeNetworkModel : NSObject

@end
